/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
struct node{
    int data;
    struct node *link;
}*top=NULL;

int isEmpty(){
    if(top==NULL)
        return 1;
    else
       return 0;
}
void push(int data){
    struct node *newNode;
    newNode=malloc(sizeof(newNode));
    if(newNode==NULL){
        printf("stack overflown");
        exit(1);
    }
    newNode->data=data;
    newNode->link=NULL;
    newNode->link=top;
    top=newNode;
}
int pop(){
    struct node *temp;
    temp=top;
    if(isEmpty()){
        printf("stack underflow");
        exit(1);
    }
    int value=temp->data;
    top=top->link;
    free(temp);
    temp=NULL;
    return value;
}

void print(){
    struct node* temp;
    temp=top;
    if(isEmpty()){
        printf("stack underflow");
        exit(1);
    }
    printf("The stack elements are:");
    while(temp){
        printf("%d",temp->data);
        temp=temp->link;
        printf("\n");
    }
}

int peek(){
    if(isEmpty()){
        printf("stack underflow");
        exit(1);
    }
    return top->data;
}


int main()
{
    int choice,data;
    while(1){
        printf("1.push\n");
        printf("2.pop\n");
        printf("3.print the all elements of the stack\n");
        printf("4.print the top element of the stack\n");
        printf("5.Quit\n");
        printf("please enter your choice:");
        scanf("%d",&choice);
        switch(choice){
            
            case 1:
            printf("Enter the element to be pushed:");
            scanf("%d",&data);
            push(data);
            break;
            
            case 2:
            data=pop();
            printf("Deleted element is :%d\n",data);
            break;
            
            case 3:
            print();
            break;
            
            case 4:
            data=peek();
            printf("top element is :%d\n",data);
            break;
            
            case 5:
            exit(1);
            
            default:
            printf("wrong choice");
        }
    }
   
    return 0;
}



