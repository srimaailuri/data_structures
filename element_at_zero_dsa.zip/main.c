/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>

#define MAX 5
int stack_array[MAX];
int first=-1;
int isEmpty(){
    if(first==-1)
        return 1;
    else
       return 0;
}

int isfull(){
    if(first==MAX-1)
      return 1;
    else
      return 0;
}

int peek(){
    if(isEmpty()){
        printf("stack underflow");
        exit(1);
    }
    return stack_array[0];
}

void push(int data){
    int i;
    first+=1;
    for(i=first;i>0;i--){
        stack_array[i]=stack_array[i-1];
    }
    stack_array[0]=data;
}
int pop(){
    int value,i;
    value=stack_array[0];
    for(i=0;i<first;i++){
        stack_array[i]=stack_array[i+1];
    }
    first-=1;
    return value;
}
void print(){
    int i;
    if(first==-1){
        printf("stack is empty");
        exit(1);
    }
    for(i=0;i<=first;i++){
        printf("%d",stack_array[i]);
    printf("\n");
    }
}
int main()
{
    int choice,data;
    while(1){
        printf("1.push\n");
        printf("2.pop\n");
        printf("3.print the top element of the stack\n");
        printf("4.print the all elements of the stack\n");
        printf("5.Quit\n");
        printf("please enter your choice:");
        scanf("%d",&choice);
        switch(choice){
            
            case 1:
            printf("Enter the element to be pushed:");
            scanf("%d",&data);
            push(data);
            break;
            
            case 2:
            data=pop();
            printf("Element poped is : %d\n",data);
            break;
            
            case 3:
            data=peek();
            printf("%d is the top element of the stack\n",data);
            break;
            
            case 4:
            print();
            break;
            
            case 5:
            exit(1);
            
            default:
            printf("wrong choice\n");
        }
    }
    
    return 0;
}




