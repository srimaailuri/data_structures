/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#define MAX 10
int stack_array[MAX];
int top=-1;
void push(int data){
    if(top==MAX-1){
        printf("stack overflown");
        return;
    }
    top=top+1;
    stack_array[top]=data;
}
int pop(){
    int value;
    if(top==-1){
        printf("stack underflow");
        exit(1);
    }
    value=stack_array[top];
    top=top-1;
    return value;
}
void prime_factor(int num){
    int i=2;
    while(num!=1){
        while(num%i==0){
            push(i);
            num=num/i; }
            i++; }
            while(top!=-1){
                printf(" %d",pop());
            }
}
int main(){
    int number;
    printf("please enter a number:");
    scanf("%d",&number);
    prime_factor(number);
    return 0;
}
