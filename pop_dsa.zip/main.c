/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#define MAX 4
int stack_array[MAX];
int top=-1;
void push(int data){
    if(top==MAX-1){
        printf("stack overflown");
        return;
    }
    top=top+1;
    stack_array[top]=data;
}

int pop(){
    int value;
    if(top==-1){
        printf("stack underflow");
        exit(1);
    }
    value=stack_array[top];
    top=top-1;
    return value;
}
void print(){
    int i;
    if(top==-1){
        printf("stack underflow");
        return;
    }
    for(i=0;i<=top;i++){
        printf("%d",stack_array[i]);
    printf("\n");
    }
}

int main()
{
    int data;
    push(1);
    push(2);
    push(3);
    push(4);
    data=pop();
    data=pop();
    print();

    return 0;
}
